/* The following will display the result of 19/21. First time since they are both integers
it will output 0. 
Second time integer1 is cast into double:19.0 so it should be a floating point
division of 19.0/21. 
Third time it will do integer division again as integer1/integer2 are in parentheses. It will cast into double
afterward so the output will be 0*/