/*The following output should simply type in numbers 1-5 while making a
new line each time*/