/* 
 * Author: Tyler Purba
 * Date: 2025-09-11
 * Purpose: Display the 5th number in a sequence from 0 to 100 in increments of 5
 */

#include <iostream>
using namespace std;

int main()
{
    for (int i = 0; i<=100; i+=5) {
       
        cout << i <<endl;
    }
    
    return 0;
}