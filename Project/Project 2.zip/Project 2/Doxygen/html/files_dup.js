var files_dup =
[
    [ "brd.h", "brd_8h_source.html", null ],
    [ "cfg.h", "cfg_8h_source.html", null ],
    [ "Game.h", "_game_8h_source.html", null ],
    [ "Hm2.h", "_hm2_8h_source.html", null ],
    [ "Hmn.h", "_hmn_8h_source.html", null ],
    [ "plfunc.h", "plfunc_8h_source.html", null ],
    [ "Plyr.h", "_plyr_8h_source.html", null ],
    [ "Ship.h", "_ship_8h_source.html", null ],
    [ "Stat.h", "_stat_8h_source.html", null ],
    [ "stfunc.h", "stfunc_8h_source.html", null ]
];