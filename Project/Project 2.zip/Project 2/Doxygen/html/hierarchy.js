var hierarchy =
[
    [ "Game", "class_game.html", null ],
    [ "Plyr", "class_plyr.html", [
      [ "Hm2", "class_hm2.html", null ],
      [ "Hmn", "class_hmn.html", null ]
    ] ],
    [ "Ship", "class_ship.html", null ],
    [ "Stat", "class_stat.html", null ]
];