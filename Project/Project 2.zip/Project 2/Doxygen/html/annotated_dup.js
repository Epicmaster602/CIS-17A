var annotated_dup =
[
    [ "Game", "class_game.html", null ],
    [ "Hm2", "class_hm2.html", null ],
    [ "Hmn", "class_hmn.html", null ],
    [ "Plyr", "class_plyr.html", null ],
    [ "Ship", "class_ship.html", null ],
    [ "Stat", "class_stat.html", null ]
];