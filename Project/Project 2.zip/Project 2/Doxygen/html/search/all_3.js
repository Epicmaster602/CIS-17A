var searchData=
[
  ['ship_0',['Ship',['../class_ship.html',1,'']]],
  ['stat_1',['Stat',['../class_stat.html',1,'']]]
];
