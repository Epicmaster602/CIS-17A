#ifndef CFG_H
#define CFG_H

const int ROWS = 14;   // A-N
const int COLS = 14;   // 1-14
const int SNUM = 5;    // ships

#endif
