#include <iostream>
using namespace std;

int main() {
    cout << "Largest n such that n! fits in each type"<<endl;

    cout << "signed char: n = 5"<<endl;
    cout << "unsigned char: n = 5"<<endl;

    cout << "short: n = 7"<<endl;
    cout << "unsigned short: n = 8"<<endl;

    cout << "int: n = 12"<<endl;
    cout << "unsigned int: n = 12"<<endl;

    cout << "long: n = 12"<<endl;
    cout << "unsigned long: n = 12"<<endl;

    cout << "long long: n = 20"<<endl;
    cout << "unsigned long long: n = 20"<<endl;

    cout << "float: n = 34"<<endl;
    cout << "double: n = 170"<<endl;

    cout << "long double: n = 170 "<<endl;
 

    return 0;
}
