/* 
 * Author: Tyler Purba
 * Date:September 15, 2025
 * Purpose:A "Hello World" program
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<endl;
    cout<<"   Hello World!  "<<endl;
    cout<<endl;
    //Exit
    return 0;
}